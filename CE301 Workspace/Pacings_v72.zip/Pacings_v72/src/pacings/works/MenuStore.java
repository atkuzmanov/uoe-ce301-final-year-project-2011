package pacings.works;

import java.util.ArrayList;

public class MenuStore {
	public static int spinnerselection = -1;
	public static String searchbar = "";
	public static boolean listitemselected = false;
	public static boolean showhidemenu = false;
	public static int itemPosition = -1;
	public static long listonclickid = -1;
	public static ArrayList<Long> listItemsIds = new ArrayList<Long>();

	public MenuStore() {
	}
}
